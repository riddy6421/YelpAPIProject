package com.example.yelpapiproject.model

data class Category(
    val alias: String,
    val title: String
)