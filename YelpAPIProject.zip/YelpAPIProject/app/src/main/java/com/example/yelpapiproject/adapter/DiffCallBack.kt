package com.example.yelpapiproject.adapter

import androidx.recyclerview.widget.DiffUtil
import com.example.yelpapiproject.model.Businesses

class DiffCallBack {
    companion object {
        val diffCallback = object : DiffUtil.ItemCallback<Businesses>() {
            override fun areItemsTheSame(oldItem: Businesses, newItem: Businesses): Boolean {
                return oldItem.id.equals(newItem)
            }
            override fun areContentsTheSame(oldItem: Businesses, newItem: Businesses): Boolean {
                return oldItem == newItem
            }
        }
    }
}