package com.example.yelpapiproject.threading

import kotlinx.coroutines.CoroutineDispatcher

interface DispatcherProviderInterface {
    val main: CoroutineDispatcher
    val io: CoroutineDispatcher
    val default: CoroutineDispatcher
    val unconfined : CoroutineDispatcher
}