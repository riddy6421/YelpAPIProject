package com.example.yelpapiproject

import android.os.Bundle
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.yelpapiproject.adapter.FoodItemRecyclerViewAdapter
import com.example.yelpapiproject.databinding.ActivityMainBinding
import com.example.yelpapiproject.viewmodel.FoodItemViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val mFoodItemViewModel: FoodItemViewModel by viewModels()
    private lateinit var mFoodItemRecyclerViewAdapter: FoodItemRecyclerViewAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initRecyclerview()
        CollectData()
    }

    private fun CollectData(){
        lifecycleScope.launch{
            mFoodItemViewModel.foodItemLiveData.collectLatest {
                mFoodItemRecyclerViewAdapter.submitData(it)
            }
        }
    }

    private fun initRecyclerview(){
        mFoodItemRecyclerViewAdapter = FoodItemRecyclerViewAdapter()
        binding.homeContent.recyclerview.apply {
            adapter = mFoodItemRecyclerViewAdapter
            layoutManager = LinearLayoutManager(applicationContext)
        }
    }
}