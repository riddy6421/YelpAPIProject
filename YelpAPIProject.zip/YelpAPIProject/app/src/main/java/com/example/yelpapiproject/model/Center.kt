package com.example.yelpapiproject.model

data class Center(
    val latitude: Double,
    val longitude: Double
)