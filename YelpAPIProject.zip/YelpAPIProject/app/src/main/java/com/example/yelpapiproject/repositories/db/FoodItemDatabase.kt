package com.example.yelpapiproject.repositories.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.yelpapiproject.model.Businesses

@Database(entities = [Businesses::class], version = 1)
abstract class FoodItemDatabase: RoomDatabase() {
    abstract fun foodItemDao(): FoodItemDao
}