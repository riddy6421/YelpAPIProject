package com.example.yelpapiproject.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.yelpapiproject.R
import com.example.yelpapiproject.model.Businesses
import com.example.yelpapiproject.databinding.FoodItemViewBinding
import com.example.yelpapiproject.viewholder.FoodItemViewHolder

class FoodItemRecyclerViewAdapter: PagingDataAdapter<Businesses, FoodItemViewHolder>(DiffCallBack.diffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodItemViewHolder {
        return FoodItemViewHolder(
            FoodItemViewBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        )
    }
    override fun onBindViewHolder(holder: FoodItemViewHolder, position: Int) {
       val businesses:Businesses? = getItem(position)
        holder.binding.apply {
            holder.itemView.apply {
                name.text = businesses?.name
                phone.text = businesses?.phone
                distance.text = businesses?.distance.toString()
                Glide.with(this).load(businesses?.image_url).into(businessImage);
            }
        }
    }
}