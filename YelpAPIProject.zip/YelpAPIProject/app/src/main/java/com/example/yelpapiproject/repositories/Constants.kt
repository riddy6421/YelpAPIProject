package com.example.yelpapiproject.repositories

import com.example.yelpapiproject.BuildConfig

class Constants {
    companion object{
        const val BASE_URL = "https://api.yelp.com"
        const val SUBDOMAIN = "/v3/businesses/search?".plus(BuildConfig.Location)
    }
}