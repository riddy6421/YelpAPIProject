package com.example.yelpapiproject.di

import com.example.yelpapiproject.BuildConfig
import com.example.yelpapiproject.repositories.Constants
import com.example.yelpapiproject.repositories.network.NetworkApiInterface
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ActivityComponent
import dagger.hilt.android.scopes.ActivityScoped
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton


@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    @Provides
    @Singleton
    fun provideLoggingInterceptor(): OkHttpClient.Builder{
        val logging = HttpLoggingInterceptor()
        logging.setLevel(HttpLoggingInterceptor.Level.BODY)
        val httpClient = OkHttpClient.Builder()
        httpClient.addInterceptor(logging)
        return httpClient;
    }

    @Provides
    @Singleton
    fun provideRetrofitInstance(httpClient: OkHttpClient.Builder): Retrofit {
        return Retrofit.Builder().
        baseUrl(Constants.BASE_URL).
        addConverterFactory(GsonConverterFactory.create()).
        client(httpClient.build()).
        build()
    }

    @Provides
    @Singleton
    fun provideRetroService(retrofit: Retrofit): NetworkApiInterface {
        return retrofit.create(NetworkApiInterface::class.java)
    }
}