package com.example.yelpapiproject.repositories.db

import androidx.paging.PagingSource
import androidx.room.*
import com.example.yelpapiproject.model.Businesses

@Dao
interface FoodItemDao {

    @Query("SELECT * FROM food_item_table")
    fun getAll(): PagingSource<Int,Businesses>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(business: List<Businesses>)

    @Update
    suspend fun update(businesses: Businesses)

    @Delete
    suspend fun delete(businesses: Businesses)

    @Query("DELETE FROM food_item_table")
    suspend fun deleteAll()
}
