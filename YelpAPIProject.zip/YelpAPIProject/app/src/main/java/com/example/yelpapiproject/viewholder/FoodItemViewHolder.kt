package com.example.yelpapiproject.viewholder

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.yelpapiproject.databinding.FoodItemViewBinding
import com.example.yelpapiproject.R

 class FoodItemViewHolder(
        val binding: FoodItemViewBinding
    ) : RecyclerView.ViewHolder(binding.root)
