package com.example.yelpapiproject.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "food_item_table")
data class Businesses(
    @PrimaryKey
    val id: String,
    val display_phone: String,
    val distance: Double,
    val image_url: String,
    val name: String,
    val phone: String
)