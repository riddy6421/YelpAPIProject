package com.example.yelpapiproject.di

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.yelpapiproject.R
import com.example.yelpapiproject.repositories.db.FoodItemDao
import com.example.yelpapiproject.repositories.db.FoodItemDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides
    @Singleton
    fun provideFoodItemDatabase(@ApplicationContext appContext: Context): FoodItemDatabase {
         val migration_1_2: Migration = object: Migration(1,2) {
             override fun migrate(database: SupportSQLiteDatabase) {
             }
         }
        return Room.databaseBuilder(
            appContext,
            FoodItemDatabase::class.java,
            appContext.getString(R.string.db_name)
        ).build()
    }

    @Provides
    @Singleton
    fun provideFoodItemDao(foodItemDatabase: FoodItemDatabase): FoodItemDao {
        return foodItemDatabase.foodItemDao()
    }
}