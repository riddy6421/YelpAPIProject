package com.example.yelpapiproject.model

data class FoodItemModel(
    val businesses: List<Businesses>,
    val region: Region,
    val total: Int
)