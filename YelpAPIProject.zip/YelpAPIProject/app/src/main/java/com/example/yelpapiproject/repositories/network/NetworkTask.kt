package com.example.yelpapiproject.repositories.network

import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.example.yelpapiproject.R
import com.example.yelpapiproject.model.Businesses
import com.example.yelpapiproject.model.FoodItemModel
import com.example.yelpapiproject.model.FoodItemResponse
import com.example.yelpapiproject.repositories.cache.FoodItemDiskCache
import com.example.yelpapiproject.threading.AppDispatchers
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response
import javax.inject.Inject

class NetworkTask @Inject constructor(@ApplicationContext private val context: Context,
                                      private val networkApiInterface: NetworkApiInterface,
                                      private val foodItemDiskCache: FoodItemDiskCache
){

    private lateinit var errorMessage:String
    private lateinit var responsePizza : Response<FoodItemModel>
    private lateinit var responseBeer : Response<FoodItemModel>

    var mErrorMessageLiveData : MutableLiveData<String> = MutableLiveData()

    suspend fun initDownloadData(){
        responsePizza = networkApiInterface.getFoodItemData(encodePizzaQueries())
        responseBeer = networkApiInterface.getFoodItemData(encodeBeerQueries())
        checkDataResponse()
    }

    private suspend fun checkDataResponse(){
        if(responsePizza.isSuccessful && responseBeer.isSuccessful){
            withContext(Dispatchers.IO){ saveDataToCache(getListOfBusinesses(responseBeer,responsePizza))}
        }else{
            setError()
        }
    }

    private fun getListOfBusinesses(beerApiResponse: Response<FoodItemModel>,
                                    pizzaApiResponse: Response<FoodItemModel>): List<Businesses>{
        val responseData = mutableListOf<Businesses>()
        val data_pizza = pizzaApiResponse.body()?.businesses
        val data_beer = beerApiResponse.body()?.businesses

        data_pizza?.let { responseData.addAll(it)}
        data_beer?.let { responseData.addAll(it)}
        return responseData
    }

    private fun encodePizzaQueries() : Map<String, String>{
        val queryMap = mutableMapOf<String,String>()
        queryMap["term"] = context.getString(R.string.pizza)
        return queryMap;
    }

    private fun encodeBeerQueries() : Map<String, String>{
        val queryMap = mutableMapOf<String,String>()
        queryMap["term"] = context.getString(R.string.beer)
        return queryMap;
    }

     private fun setError() {
         errorMessage = context.getString(R.string.Error_Message)
         mErrorMessageLiveData.value = errorMessage
     }

    private suspend fun saveDataToCache(dataList:List<Businesses>) {
     //   foodItemDiskCache.clearCache()
        foodItemDiskCache.addDataToDiskCache(dataList)
    }
    fun getDataFromCache(): PagingSource<Int,Businesses> = foodItemDiskCache.getDataFromDiskCache()

}