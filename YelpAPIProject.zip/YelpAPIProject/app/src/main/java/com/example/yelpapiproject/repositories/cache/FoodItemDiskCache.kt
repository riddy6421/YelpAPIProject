package com.example.yelpapiproject.repositories.cache

import androidx.paging.PagingSource
import com.example.yelpapiproject.model.Businesses
import com.example.yelpapiproject.repositories.db.FoodItemRepo
import javax.inject.Inject

class FoodItemDiskCache @Inject constructor(private val foodItemRepo: FoodItemRepo) {
    suspend fun addDataToDiskCache(dataList: List<Businesses>) = foodItemRepo.insertAll(dataList)
    fun getDataFromDiskCache(): PagingSource<Int, Businesses> = foodItemRepo.getAllFoodItemData()
    suspend fun removeItemFromCache(businesses: Businesses) = foodItemRepo.delete(businesses)
    suspend fun clearCache() = foodItemRepo.deleteAll()
}