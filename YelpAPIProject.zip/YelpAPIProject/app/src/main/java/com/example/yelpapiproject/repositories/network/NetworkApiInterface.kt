package com.example.yelpapiproject.repositories.network

import com.example.yelpapiproject.BuildConfig
import com.example.yelpapiproject.model.FoodItemModel
import com.example.yelpapiproject.model.FoodItemResponse
import com.example.yelpapiproject.repositories.Constants
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Query
import retrofit2.http.QueryMap

interface NetworkApiInterface {
    @GET(Constants.SUBDOMAIN)
    @Headers("Authorization: ".plus(BuildConfig.YELP_API_KEY))
    suspend fun getFoodItemData(@QueryMap queryParams: Map<String, String> = mapOf()):
            Response<FoodItemModel>
}