package com.example.yelpapiproject.di

import com.example.yelpapiproject.threading.DispatcherProviderInterface
import com.example.yelpapiproject.threading.AppDispatchers
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DispatcherModule {
    @Singleton
    @Provides
    fun provideDispatchers(): DispatcherProviderInterface = AppDispatchers()
}