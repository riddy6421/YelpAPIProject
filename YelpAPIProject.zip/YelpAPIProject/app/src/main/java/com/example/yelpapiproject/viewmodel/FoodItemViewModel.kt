package com.example.yelpapiproject.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import com.example.yelpapiproject.model.Businesses
import com.example.yelpapiproject.repositories.network.NetworkTask
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FoodItemViewModel @Inject constructor(
    private val mNetworkTask: NetworkTask,
): ViewModel() {
    val foodItemLiveData  = Pager(
        PagingConfig(pageSize = 20,
            enablePlaceholders = true,
            maxSize = 100))
    {
        mNetworkTask.getDataFromCache()
    }.flow

    val errorLiveData:LiveData<String> = mNetworkTask.mErrorMessageLiveData

    init {
        viewModelScope.launch {
            mNetworkTask.initDownloadData()
        }
    }

}