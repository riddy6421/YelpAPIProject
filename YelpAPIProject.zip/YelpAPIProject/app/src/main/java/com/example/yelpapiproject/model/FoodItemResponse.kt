package com.example.yelpapiproject.model

data class FoodItemResponse(
    val result : FoodItemModel
)
