package com.example.yelpapiproject.model

data class Coordinates(
    val latitude: Double,
    val longitude: Double
)