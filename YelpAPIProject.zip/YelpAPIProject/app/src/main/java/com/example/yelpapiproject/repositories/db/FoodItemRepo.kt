package com.example.yelpapiproject.repositories.db

import androidx.paging.PagingSource
import com.example.yelpapiproject.model.Businesses
import javax.inject.Inject

class FoodItemRepo @Inject constructor(private val foodItemDao: FoodItemDao){
    fun getAllFoodItemData() : PagingSource<Int, Businesses> = foodItemDao.getAll()
    suspend fun insertAll(businessesDataList:List<Businesses>) = foodItemDao.insertAll(businessesDataList)
    suspend fun delete(businesses: Businesses) = foodItemDao.delete(businesses)
    suspend fun deleteAll() = foodItemDao.deleteAll()
}