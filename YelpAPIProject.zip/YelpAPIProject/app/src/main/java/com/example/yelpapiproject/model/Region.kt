package com.example.yelpapiproject.model

data class Region(
    val center: Center
)